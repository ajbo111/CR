# Bloxflip-auto-rain-joiner

## CS v1.0:
- LAUNCHED


-----------------------------------------------------------------------------------------------------------------------------------------------------------------------

## Information:
- When there is a rain at [bloxflip](https://bloxflip.com) this program will join the rain
- If you dont trust it, its literally open source

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------

## Installation:
1) download the latest version of the program
2) Extract the files to a folder of your choice
3) Install Python, this can be found in #downloads in the discord  https://discord.gg/JhPukj9qsP .
4) run the **"installer.bat"** file
5) Run AutoRain.py


-----------------------------------------------------------------------------------------------------------------------------------------------------------------------

## Notes:
- Best If Ran Overnight or on a another unused pc on the side.